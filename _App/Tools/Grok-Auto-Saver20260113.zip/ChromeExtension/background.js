// background.js - GrokSaver v2.0 Stable (Fixed)
// 機能: Grokフォルダ保存(画像)、重複防止(ハッシュ&ファイル名)、プロンプト保存(キュー対応)、Favoritesログ
// 対策: ファイル名起因のエラーを「英数字限定」にすることで完全回避
// 競合対策: onDeterminingFilename監視を撤廃

const STORAGE_KEY = "grok_saver_history";         
const FILENAME_KEY = "grok_saver_filenames";      
const PROMPT_HASH_KEY = "grok_saver_prompts";     
const PROMPT_TEXT_KEY = "grok_saver_prompt_texts";
const MIN_FILE_SIZE_KB = 100; 

// ★変更★ 保存先ルートフォルダ名
const ROOT_FOLDER = "Grok-Auto-Saver";

const monitoredDownloadIds = new Set();

// ------------------------------------
// 共通ヘルパー関数
// ------------------------------------
async function generateHash(message) {
    const msgUint8 = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function getDateString() {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}${m}${d}`;
}

function createFallbackFilename(ext = ".jpg") {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, ''); 
    const randomStr = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `grok_image_${getDateString()}_${timeStr}_${randomStr}${ext}`;
}

// ファイル名の超・強力サニタイズ
function getSafeFilenameFromUrl(url) {
    try {
        const urlObj = new URL(url);
        let rawFilename = urlObj.pathname.substring(urlObj.pathname.lastIndexOf('/') + 1);
        let filename = decodeURIComponent(rawFilename);

        filename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
        filename = filename.replace(/_+/g, '_'); 
        filename = filename.trim();
        filename = filename.replace(/[. ]+$/, ''); 

        if (filename.length > 100) filename = filename.substring(0, 100);

        if (!filename || filename === "." || filename === ".." || filename === "_") {
            return null;
        }

        if (!filename.includes('.')) filename += ".jpg"; 

        return filename;
    } catch (e) {
    }
    return null;
}

// ------------------------------------
// 履歴管理
// ------------------------------------
async function isDuplicateHash(id) {
    return new Promise((resolve) => {
        chrome.storage.local.get([STORAGE_KEY], (result) => {
            const history = result[STORAGE_KEY] || [];
            resolve(history.includes(id));
        });
    });
}

async function isDuplicateFilename(filename) {
    return new Promise((resolve) => {
        chrome.storage.local.get([FILENAME_KEY], (result) => {
            const history = result[FILENAME_KEY] || [];
            resolve(history.includes(filename));
        });
    });
}

function addToHistory(hashId, filename) {
    chrome.storage.local.get([STORAGE_KEY, FILENAME_KEY], (result) => {
        const hashHistory = result[STORAGE_KEY] || [];
        if (hashId && !hashHistory.includes(hashId)) {
            if (hashHistory.length > 5000) hashHistory.shift();
            hashHistory.push(hashId);
        }

        const nameHistory = result[FILENAME_KEY] || [];
        if (filename && !nameHistory.includes(filename)) {
            if (nameHistory.length > 5000) nameHistory.shift();
            nameHistory.push(filename);
        }

        chrome.storage.local.set({ 
            [STORAGE_KEY]: hashHistory,
            [FILENAME_KEY]: nameHistory
        });
    });
}

function addToPromptHistory(hashId) {
    chrome.storage.local.get([PROMPT_HASH_KEY], (result) => {
        const history = result[PROMPT_HASH_KEY] || [];
        if (history.length > 5000) history.shift();
        history.push(hashId);
        chrome.storage.local.set({ [PROMPT_HASH_KEY]: history });
    });
}

function savePromptText(text) {
    chrome.storage.local.get([PROMPT_TEXT_KEY], (result) => {
        const texts = result[PROMPT_TEXT_KEY] || [];
        texts.unshift({
            date: new Date().toLocaleString('ja-JP'),
            text: text
        });
        if (texts.length > 100) texts.pop();
        chrome.storage.local.set({ [PROMPT_TEXT_KEY]: texts });
    });
}

// ------------------------------------
// メッセージ受信
// ------------------------------------
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "download_image" && request.src) {
        handleImageRequest(request.src, request.isFavorites);
    } 
    else if (request.action === "save_prompt" && request.text) {
        handlePromptRequest(request.text);
    }
});

// ------------------------------------
// キュー処理システム
// ------------------------------------
let isProcessingQueue = false;
const downloadQueue = [];

function processDownloadQueue() {
    if (isProcessingQueue || downloadQueue.length === 0) return;

    isProcessingQueue = true;
    const item = downloadQueue.shift();

    console.log(`[GrokSaver] 処理開始: ${item.filename}`);

    chrome.downloads.download({
        url: item.url,
        filename: item.filename,
        conflictAction: "uniquify",
        saveAs: false
    }, (downloadId) => {
        if (chrome.runtime.lastError) {
            console.error(`[GrokSaver] 保存失敗: ${item.filename}`, chrome.runtime.lastError.message);
            
            if (!item.isRetry && !item.isLog) {
                const ext = item.filename.includes('.txt') ? '.txt' : '.jpg';
                const simpleName = `grok_fallback_${Date.now()}${ext}`;
                console.log(`[GrokSaver] 再試行: ${simpleName}`);
                
                downloadQueue.unshift({
                    ...item,
                    filename: simpleName,
                    isRetry: true
                });
            }
        } else {
            monitoredDownloadIds.add(downloadId);
            
            if (!item.isLog) {
                const simpleFilename = item.filename.split('/').pop();
                addToHistory(item.uniqueId, simpleFilename);
            } else if (item.isPrompt) {
                addToPromptHistory(item.uniqueId);
            }
            
            console.log(`[GrokSaver] 保存成功: ${item.filename}`);
        }

        setTimeout(() => {
            isProcessingQueue = false;
            processDownloadQueue();
        }, 300);
    });
}

// ------------------------------------
// Favoritesログ バッファリング
// ------------------------------------
let favoritesBuffer = [];
let favFlushTimer = null;

function saveFavoritesLog(imageFilename, imageId) {
    const now = new Date();
    const logData = {
        filename: imageFilename, 
        id: imageId,
        timestamp: now.getTime(),
        date_str: now.toLocaleString('ja-JP')
    };
    
    favoritesBuffer.push(logData);
    
    if (favFlushTimer) clearTimeout(favFlushTimer);
    favFlushTimer = setTimeout(flushFavoritesBuffer, 5000);

    if (favoritesBuffer.length >= 50) {
        flushFavoritesBuffer();
    }
}

function flushFavoritesBuffer() {
    if (favFlushTimer) {
        clearTimeout(favFlushTimer);
        favFlushTimer = null;
    }
    if (favoritesBuffer.length === 0) return;

    const dataToSave = [...favoritesBuffer];
    favoritesBuffer = [];

    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, ''); 
    const randomStr = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const jsonStr = JSON.stringify(dataToSave, null, 2);
    const dataUrl = "data:application/json;charset=utf-8," + encodeURIComponent(jsonStr);
    
    // ★保存先パス
    const logFilename = `${ROOT_FOLDER}/System/FavLogs/fav_batch_${getDateString()}_${timeStr}_${randomStr}.json`;

    downloadQueue.push({
        url: dataUrl,
        filename: logFilename,
        uniqueId: null,
        isLog: true
    });
    
    processDownloadQueue();
}

// ------------------------------------
// リクエストハンドラ
// ------------------------------------
async function handleImageRequest(src, isFavorites) {
    let uniqueId = src;
    if (src.startsWith("data:")) {
        uniqueId = await generateHash(src);
    }

    let filenameOnly = null;
    if (src.startsWith("data:")) {
        filenameOnly = createFallbackFilename();
    } else {
        const safeName = getSafeFilenameFromUrl(src);
        filenameOnly = safeName ? safeName : createFallbackFilename();
    }

    let shouldSave = false;
    if (isFavorites) {
        const exists = await isDuplicateFilename(filenameOnly);
        if (!exists) {
            shouldSave = true;
        } else {
            console.log(`[GrokSaver] 既存Fav画像のためスキップ: ${filenameOnly}`);
        }
    } else {
        const exists = await isDuplicateHash(uniqueId);
        if (!exists) {
            shouldSave = true;
        }
    }

    if (shouldSave) {
        // ★保存先パス
        let targetFolder = `${ROOT_FOLDER}/${getDateString()}`;
        const fullPath = `${targetFolder}/${filenameOnly}`;
        
        downloadQueue.push({
            url: src,
            filename: fullPath,
            uniqueId: uniqueId,
            isLog: false
        });
    }

    if (isFavorites) {
        saveFavoritesLog(filenameOnly, uniqueId);
    }

    processDownloadQueue();
}

async function handlePromptRequest(text) {
    const uniqueId = await generateHash(text);
    const isDup = await new Promise(r => {
        chrome.storage.local.get([PROMPT_HASH_KEY], res => r((res[PROMPT_HASH_KEY]||[]).includes(uniqueId)));
    });
    
    if (isDup) return;

    savePromptText(text);

    const now = new Date();
    const dateStr = now.getFullYear() + "/" + 
                    (now.getMonth()+1).toString().padStart(2, '0') + "/" + 
                    now.getDate().toString().padStart(2, '0') + " " + 
                    now.getHours().toString().padStart(2, '0') + ":" + 
                    now.getMinutes().toString().padStart(2, '0') + ":" + 
                    now.getSeconds().toString().padStart(2, '0');

    const fileContent = `[${dateStr}]\n${text}\n------------------------------------\n`;
    const dataUrl = "data:text/plain;charset=utf-8," + encodeURIComponent("\uFEFF" + fileContent);

    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, ''); 
    const randomStr = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    
    // ★保存先パス
    const filename = `${ROOT_FOLDER}/Prompts/prompt_${getDateString()}_${timeStr}_${randomStr}.txt`;

    downloadQueue.push({
        url: dataUrl,
        filename: filename,
        uniqueId: uniqueId,
        isLog: false,
        isPrompt: true
    });

    processDownloadQueue();
}

// ------------------------------------
// ダウンロード完了後の処理
// ------------------------------------
chrome.downloads.onCreated.addListener((item) => {
    if (!item.url || item.url.startsWith("data:")) return;
    const isGrok = (item.referrer && item.referrer.includes("grok.com")) || 
                   (item.url && item.url.includes("grok.com"));
    if (isGrok) monitoredDownloadIds.add(item.id);
});

chrome.downloads.onChanged.addListener((delta) => {
    if (!monitoredDownloadIds.has(delta.id)) return;

    if (delta.state && delta.state.current === "complete") {
        chrome.downloads.search({id: delta.id}, (results) => {
            if (chrome.runtime.lastError || !results || results.length === 0) {
                monitoredDownloadIds.delete(delta.id);
                return;
            }

            const item = results[0];
            const fileSizeKB = item.fileSize / 1024;
            const isSafeFile = item.filename.endsWith(".mp4") || item.filename.endsWith(".txt") || item.filename.endsWith(".json");
            
            if (!isSafeFile && fileSizeKB < MIN_FILE_SIZE_KB) {
                console.log(`[GrokSaver] 削除(サイズ過小): ${item.filename}`);
                chrome.downloads.removeFile(delta.id, () => {
                    if (chrome.runtime.lastError) {} 
                    chrome.downloads.erase({id: delta.id}); 
                    monitoredDownloadIds.delete(delta.id);
                });
            } else {
                chrome.downloads.erase({id: delta.id}); 
                monitoredDownloadIds.delete(delta.id);
            }
        });
    }
});